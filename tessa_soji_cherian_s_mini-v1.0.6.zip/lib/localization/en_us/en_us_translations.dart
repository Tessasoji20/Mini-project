final Map<String, String> enUs = {
  // sign Screen
  "msg_example_email_com": "example@email.com",

  // sign Two Screen
  "msg_u2109037_rajagiri_edu_in": "u2109037@rajagiri.edu.in",

  // home Screen
  "lbl": "+",
  "lbl_40": "40",
  "lbl_choose_subject": "Choose Subject",
  "lbl_fadil": "Fadil",
  "lbl_hello_louis": "Hello Louis,\n",
  "lbl_louis_antony": "Louis Antony",
  "lbl_recent_searches": "Recent Searches",
  "lbl_youtube": "Youtube",
  "msg_elimination_of_recursio": "Elimination of recursio..",
  "msg_hello_louis_what": "Hello Louis,\nwhat are you looking for?",
  "msg_parse_tree_generation": "Parse Tree Generation",
  "msg_what_are_you_looking": "what are you looking for?",

  // branch selection Screen
  "lbl_aei": "AEI",
  "lbl_aids": "AIDS",
  "lbl_ce": "CE",
  "lbl_csbs": "CSBS",
  "lbl_cse": "CSE",
  "lbl_ece": "ECE",
  "lbl_eee": "EEE",
  "lbl_it": "IT",
  "lbl_me": "ME",
  "msg_choose_your_branch": "Choose your branch ",

  // Semester selection Screen
  "msg_choose_your_semester": "Choose your semester ",

  // subject selection Screen
  "lbl_bcvs_iii": "BCVS III",
  "lbl_bs": "BS",
  "lbl_cd_lab": "CD LAB",
  "lbl_compiler_design": "Compiler design",
  "lbl_fom": "FOM",
  "lbl_ml_lab": "ML LAB",
  "lbl_sdu": "SDU",
  "msg_choose_your_subject": "Choose your subject ",
  "msg_machine_learning": "Machine \nLearning",

  // module selection Screen
  "msg_choose_your_module": "Choose your module ",

  // Common String
  "lbl_1": "1",
  "lbl_2": "2",
  "lbl_3": "3",
  "lbl_4": "4",
  "lbl_5": "5",
  "lbl_6": "6",
  "lbl_7": "7",
  "lbl_8": "8",
  "lbl_create_account": "Create Account",
  "lbl_forgot_password": "Forgot Password",
  "lbl_password": "Password",
  "lbl_pomegranate": "Pomegranate",
  "lbl_sign_in": "Sign In",
  "lbl_username": "Username",
  "msg_don_t_have_an_account": "Don’t have an account?",
  "msg_hi_there_nice_to": "Hi there! Nice to see you again.",

// Network Error String
  "msg_network_err": "Network Error",
  "msg_something_went_wrong": "Something Went Wrong!",

  // Validation Error String
  "err_msg_please_enter_valid_email": "Please enter valid email",
};
