import 'package:tessa_soji_cherian_s_mini/core/app_export.dart';

class ApiClient extends GetConnect {}
