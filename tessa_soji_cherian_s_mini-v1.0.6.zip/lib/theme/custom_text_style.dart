import 'package:flutter/material.dart';
import '../core/app_export.dart';

/// A collection of pre-defined text styles for customizing text appearance,
/// categorized by different font families and weights.
/// Additionally, this class includes extensions on [TextStyle] to easily apply specific font families to text.

class CustomTextStyles {
  // Body text style
  static get bodyMediumBluegray900 => theme.textTheme.bodyMedium!.copyWith(
        color: appTheme.blueGray900,
      );
  static get bodyMediumIBMPlexMonoBlack900 =>
      theme.textTheme.bodyMedium!.iBMPlexMono.copyWith(
        color: appTheme.black900,
      );
  static get bodyMediumOnPrimary => theme.textTheme.bodyMedium!.copyWith(
        color: theme.colorScheme.onPrimary,
      );
  // Display text style
  static get displayMediumHandjetPrimary =>
      theme.textTheme.displayMedium!.handjet.copyWith(
        color: theme.colorScheme.primary,
        fontWeight: FontWeight.w400,
      );
  // Handjet text style
  static get handjetOnPrimary => TextStyle(
        color: theme.colorScheme.onPrimary,
        fontSize: 90.fSize,
        fontWeight: FontWeight.w300,
      ).handjet;
  static get handjetPrimary => TextStyle(
        color: theme.colorScheme.primary,
        fontSize: 77.fSize,
        fontWeight: FontWeight.w400,
      ).handjet;
  // Headline text style
  static get headlineLargeHandjetOnPrimary =>
      theme.textTheme.headlineLarge!.handjet.copyWith(
        color: theme.colorScheme.onPrimary,
        fontWeight: FontWeight.w400,
      );
  static get headlineLargeRobotoRed500 =>
      theme.textTheme.headlineLarge!.roboto.copyWith(
        color: appTheme.red500,
        fontWeight: FontWeight.w500,
      );
  static get headlineMediumBlack900 => theme.textTheme.headlineMedium!.copyWith(
        color: appTheme.black900,
      );
  static get headlineMediumRedA200 => theme.textTheme.headlineMedium!.copyWith(
        color: appTheme.redA200,
      );
  static get headlineMediumRedA200_1 =>
      theme.textTheme.headlineMedium!.copyWith(
        color: appTheme.redA200,
      );
  // I text style
  static get iBMPlexMonoBlack900 => TextStyle(
        color: appTheme.black900,
        fontSize: 6.fSize,
        fontWeight: FontWeight.w400,
      ).iBMPlexMono;
  // Title text style
  static get titleSmallPrimary => theme.textTheme.titleSmall!.copyWith(
        color: theme.colorScheme.primary,
      );
}

extension on TextStyle {
  TextStyle get handjet {
    return copyWith(
      fontFamily: 'Handjet',
    );
  }

  TextStyle get lato {
    return copyWith(
      fontFamily: 'Lato',
    );
  }

  TextStyle get roboto {
    return copyWith(
      fontFamily: 'Roboto',
    );
  }

  TextStyle get harmattan {
    return copyWith(
      fontFamily: 'Harmattan',
    );
  }

  TextStyle get iBMPlexMono {
    return copyWith(
      fontFamily: 'IBM Plex Mono',
    );
  }
}
