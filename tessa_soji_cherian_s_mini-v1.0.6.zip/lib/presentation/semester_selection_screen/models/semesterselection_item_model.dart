import '../../../core/app_export.dart';

/// This class is used in the [semesterselection_item_widget] screen.
class SemesterselectionItemModel {
  SemesterselectionItemModel({
    this.text,
    this.id,
  }) {
    text = text ?? Rx("1");
    id = id ?? Rx("");
  }

  Rx<String>? text;

  Rx<String>? id;
}
