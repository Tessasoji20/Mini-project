import '../../../core/app_export.dart';
import 'semesterselection_item_model.dart';

/// This class defines the variables used in the [semester_selection_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class SemesterSelectionModel {
  Rx<List<SemesterselectionItemModel>> semesterselectionItemList = Rx([
    SemesterselectionItemModel(text: "1".obs),
    SemesterselectionItemModel(text: "2".obs),
    SemesterselectionItemModel(text: "3".obs),
    SemesterselectionItemModel(text: "4".obs),
    SemesterselectionItemModel(text: "5".obs),
    SemesterselectionItemModel(text: "6".obs),
    SemesterselectionItemModel(text: "7".obs),
    SemesterselectionItemModel(text: "8".obs)
  ]);
}
