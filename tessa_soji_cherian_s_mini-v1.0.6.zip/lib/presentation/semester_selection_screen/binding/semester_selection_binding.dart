import '../controller/semester_selection_controller.dart';
import 'package:get/get.dart';

/// A binding class for the SemesterSelectionScreen.
///
/// This class ensures that the SemesterSelectionController is created when the
/// SemesterSelectionScreen is first loaded.
class SemesterSelectionBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => SemesterSelectionController());
  }
}
