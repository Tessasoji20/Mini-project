import 'package:tessa_soji_cherian_s_mini/core/app_export.dart';
import 'package:tessa_soji_cherian_s_mini/presentation/semester_selection_screen/models/semester_selection_model.dart';

/// A controller class for the SemesterSelectionScreen.
///
/// This class manages the state of the SemesterSelectionScreen, including the
/// current semesterSelectionModelObj
class SemesterSelectionController extends GetxController {
  Rx<SemesterSelectionModel> semesterSelectionModelObj =
      SemesterSelectionModel().obs;
}
