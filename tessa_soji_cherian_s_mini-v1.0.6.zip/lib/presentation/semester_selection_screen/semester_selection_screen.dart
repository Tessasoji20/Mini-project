import '../semester_selection_screen/widgets/semesterselection_item_widget.dart';
import 'controller/semester_selection_controller.dart';
import 'models/semesterselection_item_model.dart';
import 'package:flutter/material.dart';
import 'package:tessa_soji_cherian_s_mini/core/app_export.dart';
import 'package:tessa_soji_cherian_s_mini/widgets/app_bar/appbar_leading_image.dart';
import 'package:tessa_soji_cherian_s_mini/widgets/app_bar/appbar_subtitle.dart';
import 'package:tessa_soji_cherian_s_mini/widgets/app_bar/custom_app_bar.dart';

class SemesterSelectionScreen extends GetWidget<SemesterSelectionController> {
  const SemesterSelectionScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(),
            body: Container(
                width: 313.h,
                margin: EdgeInsets.fromLTRB(23.h, 26.v, 23.h, 5.v),
                decoration: AppDecoration.outlineBlack
                    .copyWith(borderRadius: BorderRadiusStyle.roundedBorder20),
                child: _buildSemesterSelection())));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar() {
    return CustomAppBar(
        leadingWidth: 53.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgEpBack,
            margin: EdgeInsets.only(left: 14.h, top: 5.v, bottom: 10.v),
            onTap: () {
              navigateTobranch();
            }),
        title: AppbarSubtitle(
            text: "msg_choose_your_semester".tr,
            margin: EdgeInsets.only(left: 9.h)));
  }

  /// Section Widget
  Widget _buildSemesterSelection() {
    return Obx(() => GridView.builder(
        shrinkWrap: true,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            mainAxisExtent: 125.v,
            crossAxisCount: 2,
            mainAxisSpacing: 55.h,
            crossAxisSpacing: 55.h),
        physics: NeverScrollableScrollPhysics(),
        itemCount: controller.semesterSelectionModelObj.value
            .semesterselectionItemList.value.length,
        itemBuilder: (context, index) {
          SemesterselectionItemModel model = controller
              .semesterSelectionModelObj
              .value
              .semesterselectionItemList
              .value[index];
          return SemesterselectionItemWidget(model, navigateTosub: () {
            navigateTosub();
          });
        }));
  }

  /// Navigates to the subjectSelectionScreen when the action is triggered.
  navigateTosub() {
    Get.toNamed(AppRoutes.subjectSelectionScreen);
  }

  /// Navigates to the branchSelectionScreen when the action is triggered.
  navigateTobranch() {
    Get.toNamed(
      AppRoutes.branchSelectionScreen,
    );
  }
}
