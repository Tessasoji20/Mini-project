import 'controller/splash_controller.dart';
import 'package:flutter/material.dart';
import 'package:tessa_soji_cherian_s_mini/core/app_export.dart';

class SplashScreen extends GetWidget<SplashController> {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: double.maxFinite,
                child: Column(children: [
                  SizedBox(height: 231.v),
                  Expanded(
                      child: SingleChildScrollView(
                          child: Container(
                              height: 570.v,
                              width: 286.h,
                              margin: EdgeInsets.symmetric(horizontal: 37.h),
                              child:
                                  Stack(alignment: Alignment.center, children: [
                                Align(
                                    alignment: Alignment.topCenter,
                                    child: Padding(
                                        padding: EdgeInsets.only(top: 230.v),
                                        child: Text("lbl_pomegranate".tr,
                                            style: CustomTextStyles
                                                .displayMediumHandjetPrimary))),
                                Align(
                                    alignment: Alignment.center,
                                    child: Container(
                                        height: 570.v,
                                        width: 286.h,
                                        padding: EdgeInsets.all(19.h),
                                        decoration: AppDecoration
                                            .outlineSecondaryContainer
                                            .copyWith(
                                                borderRadius: BorderRadiusStyle
                                                    .roundedBorder5),
                                        child: CustomImageView(
                                            imagePath: ImageConstant.imgImage1,
                                            height: 255.v,
                                            width: 246.h,
                                            alignment: Alignment.topCenter)))
                              ]))))
                ]))));
  }
}
