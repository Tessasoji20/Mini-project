import '../subject_selection_screen/widgets/sixteen_item_widget.dart';
import 'controller/subject_selection_controller.dart';
import 'models/sixteen_item_model.dart';
import 'package:flutter/material.dart';
import 'package:tessa_soji_cherian_s_mini/core/app_export.dart';
import 'package:tessa_soji_cherian_s_mini/widgets/app_bar/appbar_leading_image.dart';
import 'package:tessa_soji_cherian_s_mini/widgets/app_bar/appbar_subtitle.dart';
import 'package:tessa_soji_cherian_s_mini/widgets/app_bar/custom_app_bar.dart';

class SubjectSelectionScreen extends GetWidget<SubjectSelectionController> {
  const SubjectSelectionScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(),
            body: Container(
                width: 313.h,
                margin: EdgeInsets.fromLTRB(23.h, 28.v, 23.h, 5.v),
                decoration: AppDecoration.outlineBlack
                    .copyWith(borderRadius: BorderRadiusStyle.roundedBorder20),
                child: _buildSixteen())));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar() {
    return CustomAppBar(
        leadingWidth: 62.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgEpBack,
            margin: EdgeInsets.only(left: 23.h, top: 7.v, bottom: 8.v),
            onTap: () {
              navigateTosem();
            }),
        title: AppbarSubtitle(
            text: "msg_choose_your_subject".tr,
            margin: EdgeInsets.only(left: 13.h)));
  }

  /// Section Widget
  Widget _buildSixteen() {
    return Obx(() => GridView.builder(
        shrinkWrap: true,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            mainAxisExtent: 125.v,
            crossAxisCount: 2,
            mainAxisSpacing: 55.h,
            crossAxisSpacing: 55.h),
        physics: NeverScrollableScrollPhysics(),
        itemCount: controller
            .subjectSelectionModelObj.value.sixteenItemList.value.length,
        itemBuilder: (context, index) {
          SixteenItemModel model = controller
              .subjectSelectionModelObj.value.sixteenItemList.value[index];
          return SixteenItemWidget(model, navigateTomod: () {
            navigateTomod();
          });
        }));
  }

  /// Navigates to the moduleSelectionScreen when the action is triggered.
  navigateTomod() {
    Get.toNamed(AppRoutes.moduleSelectionScreen);
  }

  /// Navigates to the semesterSelectionScreen when the action is triggered.
  navigateTosem() {
    Get.toNamed(
      AppRoutes.semesterSelectionScreen,
    );
  }
}
