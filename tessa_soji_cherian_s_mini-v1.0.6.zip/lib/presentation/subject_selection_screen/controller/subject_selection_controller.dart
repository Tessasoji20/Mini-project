import 'package:tessa_soji_cherian_s_mini/core/app_export.dart';
import 'package:tessa_soji_cherian_s_mini/presentation/subject_selection_screen/models/subject_selection_model.dart';

/// A controller class for the SubjectSelectionScreen.
///
/// This class manages the state of the SubjectSelectionScreen, including the
/// current subjectSelectionModelObj
class SubjectSelectionController extends GetxController {
  Rx<SubjectSelectionModel> subjectSelectionModelObj =
      SubjectSelectionModel().obs;
}
