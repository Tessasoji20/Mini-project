import '../controller/subject_selection_controller.dart';
import 'package:get/get.dart';

/// A binding class for the SubjectSelectionScreen.
///
/// This class ensures that the SubjectSelectionController is created when the
/// SubjectSelectionScreen is first loaded.
class SubjectSelectionBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => SubjectSelectionController());
  }
}
