import '../../../core/app_export.dart';

/// This class is used in the [sixteen_item_widget] screen.
class SixteenItemModel {
  SixteenItemModel({
    this.compilerDesign,
    this.id,
  }) {
    compilerDesign = compilerDesign ?? Rx("Compiler design");
    id = id ?? Rx("");
  }

  Rx<String>? compilerDesign;

  Rx<String>? id;
}
