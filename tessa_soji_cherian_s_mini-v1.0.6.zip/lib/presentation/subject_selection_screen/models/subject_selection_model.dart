import '../../../core/app_export.dart';
import 'sixteen_item_model.dart';

/// This class defines the variables used in the [subject_selection_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class SubjectSelectionModel {
  Rx<List<SixteenItemModel>> sixteenItemList = Rx([
    SixteenItemModel(compilerDesign: "Compiler design".obs),
    SixteenItemModel(compilerDesign: "Machine \nLearning".obs),
    SixteenItemModel(compilerDesign: "SDU".obs),
    SixteenItemModel(compilerDesign: "BCVS III".obs),
    SixteenItemModel(compilerDesign: "FOM".obs),
    SixteenItemModel(compilerDesign: "BS".obs),
    SixteenItemModel(compilerDesign: "CD LAB".obs),
    SixteenItemModel(compilerDesign: "ML LAB".obs)
  ]);
}
