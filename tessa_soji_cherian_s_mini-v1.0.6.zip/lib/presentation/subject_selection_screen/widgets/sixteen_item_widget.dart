import '../controller/subject_selection_controller.dart';
import '../models/sixteen_item_model.dart';
import 'package:flutter/material.dart';
import 'package:tessa_soji_cherian_s_mini/core/app_export.dart';

// ignore: must_be_immutable
class SixteenItemWidget extends StatelessWidget {
  SixteenItemWidget(
    this.sixteenItemModelObj, {
    Key? key,
    this.navigateTomod,
  }) : super(
          key: key,
        );

  SixteenItemModel sixteenItemModelObj;

  var controller = Get.find<SubjectSelectionController>();

  VoidCallback? navigateTomod;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 13.h,
        vertical: 25.v,
      ),
      decoration: AppDecoration.fillBluegray10001.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder20,
      ),
      child: GestureDetector(
        onTap: () {
          navigateTomod!.call();
        },
        child: SizedBox(
          width: 100.h,
          child: Obx(
            () => Text(
              sixteenItemModelObj.compilerDesign!.value,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: theme.textTheme.headlineLarge,
            ),
          ),
        ),
      ),
    );
  }
}
