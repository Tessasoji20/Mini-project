import '../module_selection_screen/widgets/eight_item_widget.dart';
import 'controller/module_selection_controller.dart';
import 'models/eight_item_model.dart';
import 'package:flutter/material.dart';
import 'package:tessa_soji_cherian_s_mini/core/app_export.dart';
import 'package:tessa_soji_cherian_s_mini/widgets/app_bar/appbar_leading_image.dart';
import 'package:tessa_soji_cherian_s_mini/widgets/app_bar/appbar_subtitle.dart';
import 'package:tessa_soji_cherian_s_mini/widgets/app_bar/custom_app_bar.dart';

class ModuleSelectionScreen extends GetWidget<ModuleSelectionController> {
  const ModuleSelectionScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(),
            body: Container(
                width: 313.h,
                margin: EdgeInsets.fromLTRB(23.h, 30.v, 23.h, 5.v),
                decoration: AppDecoration.outlineBlack
                    .copyWith(borderRadius: BorderRadiusStyle.roundedBorder20),
                child: _buildEight())));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar() {
    return CustomAppBar(
        leadingWidth: 57.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgEpBack,
            margin: EdgeInsets.only(left: 18.h, top: 6.v, bottom: 9.v),
            onTap: () {
              navigateTosub();
            }),
        title: AppbarSubtitle(
            text: "msg_choose_your_module".tr,
            margin: EdgeInsets.only(left: 18.h)));
  }

  /// Section Widget
  Widget _buildEight() {
    return Obx(() => GridView.builder(
        shrinkWrap: true,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            mainAxisExtent: 125.v,
            crossAxisCount: 2,
            mainAxisSpacing: 55.h,
            crossAxisSpacing: 55.h),
        physics: NeverScrollableScrollPhysics(),
        itemCount:
            controller.moduleSelectionModelObj.value.eightItemList.value.length,
        itemBuilder: (context, index) {
          EightItemModel model = controller
              .moduleSelectionModelObj.value.eightItemList.value[index];
          return EightItemWidget(model);
        }));
  }

  /// Navigates to the subjectSelectionScreen when the action is triggered.
  navigateTosub() {
    Get.toNamed(
      AppRoutes.subjectSelectionScreen,
    );
  }
}
