import 'package:tessa_soji_cherian_s_mini/core/app_export.dart';
import 'package:tessa_soji_cherian_s_mini/presentation/module_selection_screen/models/module_selection_model.dart';

/// A controller class for the ModuleSelectionScreen.
///
/// This class manages the state of the ModuleSelectionScreen, including the
/// current moduleSelectionModelObj
class ModuleSelectionController extends GetxController {
  Rx<ModuleSelectionModel> moduleSelectionModelObj = ModuleSelectionModel().obs;
}
