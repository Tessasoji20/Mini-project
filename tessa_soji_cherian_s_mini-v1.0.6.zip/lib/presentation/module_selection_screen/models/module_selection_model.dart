import '../../../core/app_export.dart';
import 'eight_item_model.dart';

/// This class defines the variables used in the [module_selection_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class ModuleSelectionModel {
  Rx<List<EightItemModel>> eightItemList = Rx([
    EightItemModel(text: "1".obs),
    EightItemModel(text: "2".obs),
    EightItemModel(text: "3".obs),
    EightItemModel(text: "4".obs),
    EightItemModel(text: "5".obs),
    EightItemModel(text: "6".obs),
    EightItemModel(text: "7".obs),
    EightItemModel(text: "8".obs)
  ]);
}
