import '../../../core/app_export.dart';

/// This class is used in the [eight_item_widget] screen.
class EightItemModel {
  EightItemModel({
    this.text,
    this.id,
  }) {
    text = text ?? Rx("1");
    id = id ?? Rx("");
  }

  Rx<String>? text;

  Rx<String>? id;
}
