import '../controller/module_selection_controller.dart';
import '../models/eight_item_model.dart';
import 'package:flutter/material.dart';
import 'package:tessa_soji_cherian_s_mini/core/app_export.dart';

// ignore: must_be_immutable
class EightItemWidget extends StatelessWidget {
  EightItemWidget(
    this.eightItemModelObj, {
    Key? key,
  }) : super(
          key: key,
        );

  EightItemModel eightItemModelObj;

  var controller = Get.find<ModuleSelectionController>();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 53.h,
        vertical: 15.v,
      ),
      decoration: AppDecoration.fillBluegray10001.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: 6.v),
          SizedBox(
            width: 17.h,
            child: Obx(
              () => Text(
                eightItemModelObj.text!.value,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: theme.textTheme.displayMedium,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
