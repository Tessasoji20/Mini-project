import 'package:tessa_soji_cherian_s_mini/core/app_export.dart';
import 'package:tessa_soji_cherian_s_mini/presentation/sign_two_screen/models/sign_two_model.dart';
import 'package:flutter/material.dart';

/// A controller class for the SignTwoScreen.
///
/// This class manages the state of the SignTwoScreen, including the
/// current signTwoModelObj
class SignTwoController extends GetxController {
  TextEditingController userNameController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  Rx<SignTwoModel> signTwoModelObj = SignTwoModel().obs;

  Rx<bool> isShowPassword = true.obs;

  @override
  void onClose() {
    super.onClose();
    userNameController.dispose();
    passwordController.dispose();
  }
}
