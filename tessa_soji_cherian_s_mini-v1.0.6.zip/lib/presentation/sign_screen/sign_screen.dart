import 'controller/sign_controller.dart';
import 'package:flutter/material.dart';
import 'package:tessa_soji_cherian_s_mini/core/app_export.dart';
import 'package:tessa_soji_cherian_s_mini/core/utils/validation_functions.dart';
import 'package:tessa_soji_cherian_s_mini/widgets/custom_elevated_button.dart';
import 'package:tessa_soji_cherian_s_mini/widgets/custom_text_form_field.dart';

// ignore_for_file: must_be_immutable
class SignScreen extends GetWidget<SignController> {
  SignScreen({Key? key}) : super(key: key);

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: Form(
                key: _formKey,
                child: Container(
                    width: double.maxFinite,
                    padding: EdgeInsets.symmetric(vertical: 47.v),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomImageView(
                              imagePath: ImageConstant.imgImage1100x136,
                              height: 100.v,
                              width: 136.h),
                          SizedBox(height: 16.v),
                          Padding(
                              padding: EdgeInsets.only(left: 12.h),
                              child: Text("lbl_pomegranate".tr,
                                  style: CustomTextStyles.handjetPrimary)),
                          SizedBox(height: 19.v),
                          Padding(
                              padding: EdgeInsets.only(left: 16.h),
                              child: Text("lbl_sign_in".tr,
                                  style: CustomTextStyles
                                      .headlineLargeRobotoRed500)),
                          SizedBox(height: 5.v),
                          Padding(
                              padding: EdgeInsets.only(left: 16.h),
                              child: Text("msg_hi_there_nice_to".tr,
                                  style: theme.textTheme.bodyMedium)),
                          SizedBox(height: 29.v),
                          Padding(
                              padding: EdgeInsets.only(left: 16.h),
                              child: Text("lbl_username".tr,
                                  style: theme.textTheme.titleSmall)),
                          SizedBox(height: 16.v),
                          Padding(
                              padding: EdgeInsets.only(left: 16.h, right: 17.h),
                              child: CustomTextFormField(
                                  controller: controller.userNameController,
                                  hintText: "msg_example_email_com".tr,
                                  textInputType: TextInputType.emailAddress,
                                  alignment: Alignment.center,
                                  validator: (value) {
                                    if (value == null ||
                                        (!isValidEmail(value,
                                            isRequired: true))) {
                                      return "err_msg_please_enter_valid_email"
                                          .tr;
                                    }
                                    return null;
                                  })),
                          SizedBox(height: 22.v),
                          Padding(
                              padding: EdgeInsets.only(left: 16.h),
                              child: Text("lbl_password".tr,
                                  style: theme.textTheme.titleSmall)),
                          SizedBox(height: 9.v),
                          Padding(
                              padding: EdgeInsets.only(left: 16.h, right: 17.h),
                              child: Obx(() => CustomTextFormField(
                                  controller: controller.passwordController,
                                  textInputAction: TextInputAction.done,
                                  alignment: Alignment.center,
                                  suffix: InkWell(
                                      onTap: () {
                                        controller.isShowPassword.value =
                                            !controller.isShowPassword.value;
                                      },
                                      child: Container(
                                          margin: EdgeInsets.only(
                                              left: 30.h, bottom: 11.v),
                                          child: CustomImageView(
                                              imagePath: ImageConstant
                                                  .imgIconvisibility,
                                              height: 20.adaptSize,
                                              width: 20.adaptSize))),
                                  suffixConstraints:
                                      BoxConstraints(maxHeight: 31.v),
                                  obscureText:
                                      controller.isShowPassword.value))),
                          SizedBox(height: 35.v),
                          Align(
                              alignment: Alignment.center,
                              child: Text("lbl_forgot_password".tr,
                                  style: theme.textTheme.bodyMedium)),
                          SizedBox(height: 34.v),
                          CustomElevatedButton(
                              text: "lbl_sign_in".tr,
                              margin: EdgeInsets.only(left: 16.h, right: 17.h),
                              onPressed: () {
                                navigateTosignup();
                              },
                              alignment: Alignment.center),
                          SizedBox(height: 47.v),
                          Align(
                              alignment: Alignment.center,
                              child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text("msg_don_t_have_an_account".tr,
                                        style: theme.textTheme.bodyMedium),
                                    Padding(
                                        padding: EdgeInsets.only(left: 8.h),
                                        child: Text("lbl_create_account".tr,
                                            style: CustomTextStyles
                                                .titleSmallPrimary))
                                  ])),
                          SizedBox(height: 5.v)
                        ])))));
  }

  /// Navigates to the signTwoScreen when the action is triggered.
  navigateTosignup() {
    Get.toNamed(
      AppRoutes.signTwoScreen,
    );
  }
}
