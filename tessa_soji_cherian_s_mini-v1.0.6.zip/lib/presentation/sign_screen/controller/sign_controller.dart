import 'package:tessa_soji_cherian_s_mini/core/app_export.dart';
import 'package:tessa_soji_cherian_s_mini/presentation/sign_screen/models/sign_model.dart';
import 'package:flutter/material.dart';

/// A controller class for the SignScreen.
///
/// This class manages the state of the SignScreen, including the
/// current signModelObj
class SignController extends GetxController {
  TextEditingController userNameController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  Rx<SignModel> signModelObj = SignModel().obs;

  Rx<bool> isShowPassword = true.obs;

  @override
  void onClose() {
    super.onClose();
    userNameController.dispose();
    passwordController.dispose();
  }
}
