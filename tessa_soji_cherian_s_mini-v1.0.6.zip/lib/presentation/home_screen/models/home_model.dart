import '../../../core/app_export.dart';
import 'userprofile_item_model.dart';

/// This class defines the variables used in the [home_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class HomeModel {
  Rx<List<UserprofileItemModel>> userprofileItemList = Rx([
    UserprofileItemModel(
        userName: "40".obs,
        louisAntony: "Louis Antony".obs,
        userOccupation: "Parse Tree Generation".obs),
    UserprofileItemModel(
        userName: "40".obs,
        louisAntony: "Fadil".obs,
        userOccupation: "Elimination of recursio..".obs)
  ]);
}
