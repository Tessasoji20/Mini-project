import '../../../core/app_export.dart';

/// This class is used in the [userprofile_item_widget] screen.
class UserprofileItemModel {
  UserprofileItemModel({
    this.userName,
    this.louisAntony,
    this.userOccupation,
    this.id,
  }) {
    userName = userName ?? Rx("40");
    louisAntony = louisAntony ?? Rx("Louis Antony");
    userOccupation = userOccupation ?? Rx("Parse Tree Generation");
    id = id ?? Rx("");
  }

  Rx<String>? userName;

  Rx<String>? louisAntony;

  Rx<String>? userOccupation;

  Rx<String>? id;
}
