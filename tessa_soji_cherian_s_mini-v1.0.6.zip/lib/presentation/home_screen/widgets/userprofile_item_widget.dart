import '../controller/home_controller.dart';
import '../models/userprofile_item_model.dart';
import 'package:flutter/material.dart';
import 'package:tessa_soji_cherian_s_mini/core/app_export.dart';
import 'package:tessa_soji_cherian_s_mini/widgets/custom_elevated_button.dart';
import 'package:tessa_soji_cherian_s_mini/widgets/custom_icon_button.dart';

// ignore: must_be_immutable
class UserprofileItemWidget extends StatelessWidget {
  UserprofileItemWidget(
    this.userprofileItemModelObj, {
    Key? key,
  }) : super(
          key: key,
        );

  UserprofileItemModel userprofileItemModelObj;

  var controller = Get.find<HomeController>();

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Container(
        decoration: AppDecoration.outlineBlack,
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 12.h),
          decoration: AppDecoration.fillBluegray10001.copyWith(
            borderRadius: BorderRadiusStyle.roundedBorder20,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Padding(
                padding: EdgeInsets.only(top: 9.v),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CustomIconButton(
                      height: 24.adaptSize,
                      width: 24.adaptSize,
                      padding: EdgeInsets.all(2.h),
                      child: CustomImageView(
                        imagePath: ImageConstant.imgPersonfilledOnprimary,
                      ),
                    ),
                    SizedBox(height: 7.v),
                    CustomImageView(
                      imagePath: ImageConstant.imgVector,
                      height: 18.v,
                      width: 21.h,
                    ),
                    SizedBox(height: 1.v),
                    Padding(
                      padding: EdgeInsets.only(left: 8.h),
                      child: Obx(
                        () => Text(
                          userprofileItemModelObj.userName!.value,
                          style: CustomTextStyles.iBMPlexMonoBlack900,
                        ),
                      ),
                    ),
                    SizedBox(height: 3.v),
                    CustomImageView(
                      imagePath: ImageConstant.imgMaterialSymbol,
                      height: 24.adaptSize,
                      width: 24.adaptSize,
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Padding(
                  padding: EdgeInsets.only(
                    left: 4.h,
                    top: 15.v,
                    bottom: 4.v,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Obx(
                        () => Text(
                          userprofileItemModelObj.louisAntony!.value,
                          style: theme.textTheme.bodySmall,
                        ),
                      ),
                      SizedBox(height: 1.v),
                      Obx(
                        () => Text(
                          userprofileItemModelObj.userOccupation!.value,
                          style: theme.textTheme.bodyLarge!.copyWith(
                            decoration: TextDecoration.underline,
                          ),
                        ),
                      ),
                      SizedBox(height: 8.v),
                      CustomElevatedButton(
                        height: 28.v,
                        width: 95.h,
                        text: "lbl_youtube".tr,
                        buttonStyle: CustomButtonStyles.fillGray,
                        buttonTextStyle:
                            CustomTextStyles.bodyMediumIBMPlexMonoBlack900,
                        alignment: Alignment.centerRight,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
