import '../home_screen/widgets/userprofile_item_widget.dart';
import 'controller/home_controller.dart';
import 'models/userprofile_item_model.dart';
import 'package:flutter/material.dart';
import 'package:tessa_soji_cherian_s_mini/core/app_export.dart';
import 'package:tessa_soji_cherian_s_mini/widgets/app_bar/appbar_title.dart';
import 'package:tessa_soji_cherian_s_mini/widgets/app_bar/appbar_trailing_iconbutton.dart';
import 'package:tessa_soji_cherian_s_mini/widgets/app_bar/custom_app_bar.dart';
import 'package:tessa_soji_cherian_s_mini/widgets/custom_elevated_button.dart';

class HomeScreen extends GetWidget<HomeController> {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(),
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 10.h, vertical: 3.v),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 2.v),
                      Container(
                          width: 299.h,
                          margin: EdgeInsets.only(left: 11.h, right: 29.h),
                          child: RichText(
                              text: TextSpan(children: [
                                TextSpan(
                                    text: "lbl_hello_louis".tr,
                                    style:
                                        CustomTextStyles.headlineMediumRedA200),
                                TextSpan(
                                    text: "msg_what_are_you_looking".tr,
                                    style: theme.textTheme.headlineMedium)
                              ]),
                              textAlign: TextAlign.left)),
                      SizedBox(height: 4.v),
                      Divider(indent: 11.h, endIndent: 25.h),
                      SizedBox(height: 31.v),
                      _buildSixtyFour(),
                      SizedBox(height: 41.v),
                      Padding(
                          padding: EdgeInsets.only(left: 11.h),
                          child: Text("lbl_recent_searches".tr,
                              style: CustomTextStyles.headlineMediumRedA200_1)),
                      SizedBox(height: 16.v),
                      _buildUserProfile(),
                      Spacer(),
                      Align(
                          alignment: Alignment.centerRight,
                          child: Container(
                              height: 101.v,
                              width: 66.h,
                              margin: EdgeInsets.only(right: 9.h),
                              decoration: AppDecoration.outlineBlack,
                              child:
                                  Stack(alignment: Alignment.center, children: [
                                Align(
                                    alignment: Alignment.center,
                                    child: Container(
                                        height: 66.adaptSize,
                                        width: 66.adaptSize,
                                        decoration: BoxDecoration(
                                            color: appTheme.redA200,
                                            borderRadius:
                                                BorderRadius.circular(33.h)))),
                                Align(
                                    alignment: Alignment.center,
                                    child: Text("lbl".tr,
                                        style:
                                            CustomTextStyles.handjetOnPrimary))
                              ])))
                    ]))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar() {
    return CustomAppBar(
        height: 66.v,
        title: AppbarTitle(
            text: "lbl_pomegranate".tr, margin: EdgeInsets.only(left: 15.h)),
        actions: [
          AppbarTrailingIconbutton(
              imagePath: ImageConstant.imgPersonfilled,
              margin: EdgeInsets.fromLTRB(27.h, 6.v, 27.h, 9.v))
        ]);
  }

  /// Section Widget
  Widget _buildSixtyFour() {
    return SizedBox(
        height: 49.v,
        width: 339.h,
        child: Stack(alignment: Alignment.center, children: [
          Align(
              alignment: Alignment.center,
              child: Container(
                  height: 40.v,
                  width: 334.h,
                  decoration: BoxDecoration(
                      color: appTheme.deepOrange100,
                      borderRadius: BorderRadius.circular(20.h)))),
          CustomElevatedButton(
              width: 339.h,
              text: "lbl_choose_subject".tr,
              rightIcon: Container(
                  margin: EdgeInsets.only(),
                  decoration:
                      BoxDecoration(borderRadius: BorderRadius.circular(24.h)),
                  child: CustomImageView(
                      imagePath: ImageConstant.imgRectangle10,
                      height: 49.v,
                      width: 339.h)),
              buttonStyle: CustomButtonStyles.outlineBlack,
              buttonTextStyle: CustomTextStyles.headlineLargeHandjetOnPrimary,
              onPressed: () {
                navigateTobranch();
              },
              alignment: Alignment.center)
        ]));
  }

  /// Section Widget
  Widget _buildUserProfile() {
    return Align(
        alignment: Alignment.center,
        child: Padding(
            padding: EdgeInsets.only(left: 8.h, right: 16.h),
            child: Obx(() => ListView.separated(
                physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                separatorBuilder: (context, index) {
                  return SizedBox(height: 15.v);
                },
                itemCount: controller
                    .homeModelObj.value.userprofileItemList.value.length,
                itemBuilder: (context, index) {
                  UserprofileItemModel model = controller
                      .homeModelObj.value.userprofileItemList.value[index];
                  return UserprofileItemWidget(model);
                }))));
  }

  /// Navigates to the branchSelectionScreen when the action is triggered.
  navigateTobranch() {
    Get.toNamed(
      AppRoutes.branchSelectionScreen,
    );
  }
}
