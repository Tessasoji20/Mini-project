import '../controller/branch_selection_controller.dart';
import '../models/thirtyfour_item_model.dart';
import 'package:flutter/material.dart';
import 'package:tessa_soji_cherian_s_mini/core/app_export.dart';

// ignore: must_be_immutable
class ThirtyfourItemWidget extends StatelessWidget {
  ThirtyfourItemWidget(
    this.thirtyfourItemModelObj, {
    Key? key,
    this.navigatetoseme,
  }) : super(
          key: key,
        );

  ThirtyfourItemModel thirtyfourItemModelObj;

  var controller = Get.find<BranchSelectionController>();

  VoidCallback? navigatetoseme;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 25.h,
        vertical: 15.v,
      ),
      decoration: AppDecoration.fillBluegray10001.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(height: 6.v),
          GestureDetector(
            onTap: () {
              navigatetoseme!.call();
            },
            child: SizedBox(
              width: 78.h,
              child: Obx(
                () => Text(
                  thirtyfourItemModelObj.text!.value,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  style: theme.textTheme.displayMedium,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
