import '../controller/branch_selection_controller.dart';
import 'package:get/get.dart';

/// A binding class for the BranchSelectionScreen.
///
/// This class ensures that the BranchSelectionController is created when the
/// BranchSelectionScreen is first loaded.
class BranchSelectionBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => BranchSelectionController());
  }
}
