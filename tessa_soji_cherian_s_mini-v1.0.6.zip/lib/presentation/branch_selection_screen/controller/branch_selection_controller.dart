import 'package:tessa_soji_cherian_s_mini/core/app_export.dart';
import 'package:tessa_soji_cherian_s_mini/presentation/branch_selection_screen/models/branch_selection_model.dart';

/// A controller class for the BranchSelectionScreen.
///
/// This class manages the state of the BranchSelectionScreen, including the
/// current branchSelectionModelObj
class BranchSelectionController extends GetxController {
  Rx<BranchSelectionModel> branchSelectionModelObj = BranchSelectionModel().obs;
}
