import '../../../core/app_export.dart';

/// This class is used in the [thirtyfour_item_widget] screen.
class ThirtyfourItemModel {
  ThirtyfourItemModel({
    this.text,
    this.id,
  }) {
    text = text ?? Rx("CSE");
    id = id ?? Rx("");
  }

  Rx<String>? text;

  Rx<String>? id;
}
