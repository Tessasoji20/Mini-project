import '../../../core/app_export.dart';
import 'thirtyfour_item_model.dart';

/// This class defines the variables used in the [branch_selection_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class BranchSelectionModel {
  Rx<List<ThirtyfourItemModel>> thirtyfourItemList = Rx([
    ThirtyfourItemModel(text: "CSE".obs),
    ThirtyfourItemModel(text: "CSBS".obs),
    ThirtyfourItemModel(text: "AIDS".obs),
    ThirtyfourItemModel(text: "CE".obs),
    ThirtyfourItemModel(text: "ME".obs),
    ThirtyfourItemModel(text: "AEI".obs),
    ThirtyfourItemModel(text: "ECE".obs),
    ThirtyfourItemModel(text: "EEE".obs)
  ]);
}
