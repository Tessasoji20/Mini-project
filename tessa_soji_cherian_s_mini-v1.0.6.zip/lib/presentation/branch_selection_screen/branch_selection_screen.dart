import '../branch_selection_screen/widgets/thirtyfour_item_widget.dart';
import 'controller/branch_selection_controller.dart';
import 'models/thirtyfour_item_model.dart';
import 'package:flutter/material.dart';
import 'package:tessa_soji_cherian_s_mini/core/app_export.dart';
import 'package:tessa_soji_cherian_s_mini/widgets/app_bar/appbar_leading_image.dart';
import 'package:tessa_soji_cherian_s_mini/widgets/app_bar/appbar_subtitle.dart';
import 'package:tessa_soji_cherian_s_mini/widgets/app_bar/custom_app_bar.dart';

class BranchSelectionScreen extends GetWidget<BranchSelectionController> {
  const BranchSelectionScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: theme.colorScheme.onPrimaryContainer,
            appBar: _buildAppBar(),
            body: SizedBox(
                width: mediaQueryData.size.width,
                child: SingleChildScrollView(
                    padding: EdgeInsets.only(top: 30.v),
                    child: Container(
                        margin: EdgeInsets.only(
                            left: 23.h, right: 23.h, bottom: 5.v),
                        decoration: AppDecoration.outlineBlack.copyWith(
                            borderRadius: BorderRadiusStyle.roundedBorder20),
                        child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _buildThirtyFour(),
                              SizedBox(height: 37.v),
                              Container(
                                  margin: EdgeInsets.only(right: 184.h),
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 40.h, vertical: 15.v),
                                  decoration: AppDecoration.fillBluegray10001
                                      .copyWith(
                                          borderRadius: BorderRadiusStyle
                                              .roundedBorder20),
                                  child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        SizedBox(height: 6.v),
                                        SizedBox(
                                            width: 47.h,
                                            child: Text("lbl_it".tr,
                                                maxLines: 3,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.center,
                                                style: theme
                                                    .textTheme.displayMedium))
                                      ]))
                            ]))))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar() {
    return CustomAppBar(
        leadingWidth: 49.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgEpBack,
            margin: EdgeInsets.only(left: 10.h, top: 7.v, bottom: 8.v),
            onTap: () {
              onTapEpB();
            }),
        centerTitle: true,
        title: AppbarSubtitle(text: "msg_choose_your_branch".tr));
  }

  /// Section Widget
  Widget _buildThirtyFour() {
    return Obx(() => GridView.builder(
        shrinkWrap: true,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            mainAxisExtent: 125.v,
            crossAxisCount: 2,
            mainAxisSpacing: 55.h,
            crossAxisSpacing: 55.h),
        physics: NeverScrollableScrollPhysics(),
        itemCount: controller
            .branchSelectionModelObj.value.thirtyfourItemList.value.length,
        itemBuilder: (context, index) {
          ThirtyfourItemModel model = controller
              .branchSelectionModelObj.value.thirtyfourItemList.value[index];
          return ThirtyfourItemWidget(model, navigatetoseme: () {
            navigatetoseme();
          });
        }));
  }

  /// Navigates to the semesterSelectionScreen when the action is triggered.
  navigatetoseme() {
    Get.toNamed(AppRoutes.semesterSelectionScreen);
  }

  /// Navigates to the homeScreen when the action is triggered.
  onTapEpB() {
    Get.toNamed(
      AppRoutes.homeScreen,
    );
  }
}
