class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // splash images
  static String imgImage1 = '$imagePath/img_image_1.png';

  // home images
  static String imgPersonfilled = '$imagePath/img_personfilled.svg';

  static String imgRectangle10 = '$imagePath/img_rectangle_10.svg';

  static String imgPersonfilledOnprimary =
      '$imagePath/img_personfilled_onprimary.svg';

  static String imgVector = '$imagePath/img_vector.svg';

  static String imgMaterialSymbol = '$imagePath/img_material_symbol.svg';

  // Common images
  static String imgImage1100x136 = '$imagePath/img_image_1_100x136.png';

  static String imgIconvisibility = '$imagePath/img_iconvisibility.svg';

  static String imgEpBack = '$imagePath/img_ep_back.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
