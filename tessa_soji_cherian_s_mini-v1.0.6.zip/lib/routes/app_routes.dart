import 'package:tessa_soji_cherian_s_mini/presentation/splash_screen/splash_screen.dart';
import 'package:tessa_soji_cherian_s_mini/presentation/splash_screen/binding/splash_binding.dart';
import 'package:tessa_soji_cherian_s_mini/presentation/sign_screen/sign_screen.dart';
import 'package:tessa_soji_cherian_s_mini/presentation/sign_screen/binding/sign_binding.dart';
import 'package:tessa_soji_cherian_s_mini/presentation/sign_two_screen/sign_two_screen.dart';
import 'package:tessa_soji_cherian_s_mini/presentation/sign_two_screen/binding/sign_two_binding.dart';
import 'package:tessa_soji_cherian_s_mini/presentation/home_screen/home_screen.dart';
import 'package:tessa_soji_cherian_s_mini/presentation/home_screen/binding/home_binding.dart';
import 'package:tessa_soji_cherian_s_mini/presentation/branch_selection_screen/branch_selection_screen.dart';
import 'package:tessa_soji_cherian_s_mini/presentation/branch_selection_screen/binding/branch_selection_binding.dart';
import 'package:tessa_soji_cherian_s_mini/presentation/semester_selection_screen/semester_selection_screen.dart';
import 'package:tessa_soji_cherian_s_mini/presentation/semester_selection_screen/binding/semester_selection_binding.dart';
import 'package:tessa_soji_cherian_s_mini/presentation/subject_selection_screen/subject_selection_screen.dart';
import 'package:tessa_soji_cherian_s_mini/presentation/subject_selection_screen/binding/subject_selection_binding.dart';
import 'package:tessa_soji_cherian_s_mini/presentation/module_selection_screen/module_selection_screen.dart';
import 'package:tessa_soji_cherian_s_mini/presentation/module_selection_screen/binding/module_selection_binding.dart';
import 'package:tessa_soji_cherian_s_mini/presentation/app_navigation_screen/app_navigation_screen.dart';
import 'package:tessa_soji_cherian_s_mini/presentation/app_navigation_screen/binding/app_navigation_binding.dart';
import 'package:get/get.dart';

class AppRoutes {
  static const String splashScreen = '/splash_screen';

  static const String signScreen = '/sign_screen';

  static const String signTwoScreen = '/sign_two_screen';

  static const String homeScreen = '/home_screen';

  static const String branchSelectionScreen = '/branch_selection_screen';

  static const String semesterSelectionScreen = '/semester_selection_screen';

  static const String subjectSelectionScreen = '/subject_selection_screen';

  static const String moduleSelectionScreen = '/module_selection_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static List<GetPage> pages = [
    GetPage(
      name: splashScreen,
      page: () => SplashScreen(),
      bindings: [
        SplashBinding(),
      ],
    ),
    GetPage(
      name: signScreen,
      page: () => SignScreen(),
      bindings: [
        SignBinding(),
      ],
    ),
    GetPage(
      name: signTwoScreen,
      page: () => SignTwoScreen(),
      bindings: [
        SignTwoBinding(),
      ],
    ),
    GetPage(
      name: homeScreen,
      page: () => HomeScreen(),
      bindings: [
        HomeBinding(),
      ],
    ),
    GetPage(
      name: branchSelectionScreen,
      page: () => BranchSelectionScreen(),
      bindings: [
        BranchSelectionBinding(),
      ],
    ),
    GetPage(
      name: semesterSelectionScreen,
      page: () => SemesterSelectionScreen(),
      bindings: [
        SemesterSelectionBinding(),
      ],
    ),
    GetPage(
      name: subjectSelectionScreen,
      page: () => SubjectSelectionScreen(),
      bindings: [
        SubjectSelectionBinding(),
      ],
    ),
    GetPage(
      name: moduleSelectionScreen,
      page: () => ModuleSelectionScreen(),
      bindings: [
        ModuleSelectionBinding(),
      ],
    ),
    GetPage(
      name: appNavigationScreen,
      page: () => AppNavigationScreen(),
      bindings: [
        AppNavigationBinding(),
      ],
    ),
    GetPage(
      name: initialRoute,
      page: () => SplashScreen(),
      bindings: [
        SplashBinding(),
      ],
    )
  ];
}
