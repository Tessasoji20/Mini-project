package com.tessasojicheriansmini.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
